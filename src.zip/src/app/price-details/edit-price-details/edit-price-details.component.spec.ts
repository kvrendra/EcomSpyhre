import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPriceDetailsComponent } from './edit-price-details.component';

describe('EditPriceDetailsComponent', () => {
  let component: EditPriceDetailsComponent;
  let fixture: ComponentFixture<EditPriceDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditPriceDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditPriceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
