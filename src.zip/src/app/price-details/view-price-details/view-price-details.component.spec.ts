import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPriceDetailsComponent } from './view-price-details.component';

describe('ViewPriceDetailsComponent', () => {
  let component: ViewPriceDetailsComponent;
  let fixture: ComponentFixture<ViewPriceDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewPriceDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewPriceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
