import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPriceDetailsComponent } from './add-price-details.component';

describe('AddPriceDetailsComponent', () => {
  let component: AddPriceDetailsComponent;
  let fixture: ComponentFixture<AddPriceDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddPriceDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddPriceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
