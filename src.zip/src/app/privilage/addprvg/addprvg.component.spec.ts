import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddprvgComponent } from './addprvg.component';

describe('AddprvgComponent', () => {
  let component: AddprvgComponent;
  let fixture: ComponentFixture<AddprvgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddprvgComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddprvgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
