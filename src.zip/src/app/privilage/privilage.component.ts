import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privilage',
  templateUrl: './privilage.component.html',
  styleUrls: ['./privilage.component.css']
})
export class PrivilageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
