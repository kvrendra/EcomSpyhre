import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditprvgComponent } from './editprvg.component';

describe('EditprvgComponent', () => {
  let component: EditprvgComponent;
  let fixture: ComponentFixture<EditprvgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditprvgComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditprvgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
