import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewprvgComponent } from './viewprvg.component';

describe('ViewprvgComponent', () => {
  let component: ViewprvgComponent;
  let fixture: ComponentFixture<ViewprvgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewprvgComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewprvgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
