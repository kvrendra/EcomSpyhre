import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-group',
  templateUrl: './item-group.component.html',
  styleUrls: ['./item-group.component.css']
})
export class ItemGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
