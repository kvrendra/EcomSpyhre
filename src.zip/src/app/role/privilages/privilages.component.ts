import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privilages',
  templateUrl: './privilages.component.html',
  styleUrls: ['./privilages.component.css']
})
export class PrivilagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
