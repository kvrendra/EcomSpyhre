import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';




const headersData = {
  headers: new HttpHeaders({
    'Content-Type':'application/json'
  }),
};




@Injectable({
  providedIn: 'root'
})

export class LoginDetailsService {

  // constructor( private http:HttpClient) { }

  //   login()
  //   {
  //     return this.http.get(' http://saapi.azaz.com/api/AdminLogins')



  //   }

  public adminlist:any[]=[];
  public url='https://saapi.azaz.com/api/AdminLogins/login'
  public baseUrlPostRoles='https://saapi.azaz.com/api/AdminRoles/'
  public getRolesURL='https://saapi.azaz.com/api/AdminRoles'
  public UTCTime=new Date()

  constructor(public http:HttpClient) {

    // this.http.get(this.url).subscribe((data:any)=>{

    //   this.adminlist=data

    // })

   }

  login(obj:any){
    console.log('from service')
    console.log(obj)
 let server_response= this.http.post(this.url,JSON.stringify(obj),headersData)





  return server_response

    // var i:any;

    // for(i=0;i<=this.adminlist.length;i++){

    //     if (this.adminlist[i].userName == username && this.adminlist[i].password == password)

    //         {

    //           return true;

    //          }

    //       }return false;

    // let resp=
    // if(resp)
    // {
    //   return true
    // }
    // else
    // {
    //   return false
    // }

  }

  rolesubmit(obj:any)
{


  return this.http.post(this.baseUrlPostRoles,JSON.stringify(obj),headersData)




}
listOfRoles()
{
  return this.http.get(this.getRolesURL)
}

deleteUsingService(id:any)
{

  return this.http.delete(this.baseUrlPostRoles+id)
}





}
